import java.awt.*;
import java.applet.*;
/*
<applet code="first" width=500 height=100>
</applet>
*/
public class first extends Applet {
public void paint(Graphics g) {
g.drawString("A Simple Applet", 20, 20);
}
public static void main(String s[])
{
	System.out.println("A simple Applet");
	
}

}
