import java.util.Scanner;
import java.lang.*;

class test
{
  public static void main(String args[])
  {
     int x=10; 
	 char c='+'; 
	 float f=10.8f; 
	 double d1=234.67;
	 boolean b1=true;
	 System.out.println(x+" "+c+" "+
	 
	 int x[]={10,20,30};
	 for(int i=0;i<3;i++)
	    System.out.println(i);
	
	 for(int i : x)
	    System.out.println(i);
		
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the length of the array:");
	int n=s.nextInt();
	int y[]=new int[n];
	System.out.println("Enter "+n+" array elements:");
	
	for(int xx=0;xx<n;xx++)
	 y[i]=s.nextInt();
	 
	 
	 
	  
		
	 
  }
} 
	
  