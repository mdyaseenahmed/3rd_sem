import newpack.*;
class impfile
{
  public static void main(String s[])
  {
     B b1=new B(1000,2000);
	 b1.display();
	 b1.printb();
  }
}