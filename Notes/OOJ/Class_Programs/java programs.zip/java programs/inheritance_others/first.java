class first
{
 public static void main(String s[])
 {
   System.out.println("Hello");
 }
}
