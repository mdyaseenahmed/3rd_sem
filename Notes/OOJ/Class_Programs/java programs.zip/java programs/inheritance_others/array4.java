
class array4
{
 public static void main(String s[])
 {
   int a1[]={1,2,3};
   int a2[];
   a2[]=new int[5];
   for(int i=0;i<5;i++)
   {
    a2[i]=Integer.parseInt(s[i]);
   }
   
   
     

 }
}
